----------------------------------------------------------------
FRED Graph Observations
Federal Reserve Economic Data, Federal Reserve Bank of St. Louis
Link: https://fred.stlouisfed.org
Help: https://fredhelp.stlouisfed.org
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-11-10 6:47 pm CST
----------------------------------------------------------------

-------------  ----------------------------------------------------------------------  ------------------------
IORB           Interest Rate on Reserve Balances (IORB Rate), Percent, Daily, Not      Data Updated: 2026-11-10
               Seasonally Adjusted
IOER           Interest Rate on Excess Reserves (IOER Rate) (DISCONTINUED), Percent,   Data Updated: 2021-07-27
               Daily, Not Seasonally Adjusted
WRESBAL        Liabilities and Capital: Other Factors Draining Reserve Balances:       Data Updated: 2026-11-05
               Reserve Balances with Federal Reserve Banks: Week Average, Millions of
               U.S. Dollars, Weekly, Not Seasonally Adjusted
WTREGEN        Liabilities and Capital: Liabilities: Deposits with F.R. Banks, Other   Data Updated: 2026-11-05
               Than Reserve Balances: U.S. Treasury, General Account: Week Average,
               Millions of U.S. Dollars, Weekly, Not Seasonally Adjusted
RRPONTSYD      Overnight Reverse Repurchase Agreements: Treasury Securities Sold by    Data Updated: 2026-11-10
               the Federal Reserve in the Temporary Open Market Operations, Billions
               of US Dollars, Daily, Not Seasonally Adjusted
DFF            Federal Funds Effective Rate, Percent, Daily, Not Seasonally Adjusted   Data Updated: 2026-11-10
RRPONTSYAWARD  Overnight Reverse Repurchase Agreements Award Rate, Percent, Daily,     Data Updated: 2026-11-10
               Not Seasonally Adjusted
TREAST         Assets: Securities Held Outright: U.S. Treasury Securities: All:        Data Updated: 2026-11-05
               Wednesday Level, Millions of U.S. Dollars, Weekly, Not Seasonally
               Adjusted
WLRRAOL        Liabilities and Capital: Liabilities: Reverse Repurchase Agreements:    Data Updated: 2026-11-05
               Others: Wednesday Level, Millions of U.S. Dollars, Weekly, Not
               Seasonally Adjusted
-------------  ----------------------------------------------------------------------  ------------------------

